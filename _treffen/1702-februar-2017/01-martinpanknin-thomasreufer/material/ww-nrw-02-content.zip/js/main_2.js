var stats, scene, renderer;
var camera;

if(!init()) update();

// init the scene
function init()
{
	if(Detector.webgl)
	{
		renderer = new THREE.WebGLRenderer({
			antialias : true
		});
		renderer.setClearColor(0xffffff, 1);
	}
	else
	{
		Detector.addGetWebGLMessage();
		return true;
	}
	
	var w = window.innerWidth;
	var h = window.innerHeight;

	renderer.setPixelRatio(window.devicePixelRatio);
	renderer.setSize(w, h);
	document.getElementById('container').appendChild(renderer.domElement);

	stats = new Stats();
	stats.domElement.style.position	= 'absolute';
	stats.domElement.style.bottom = '0px';
	document.body.appendChild(stats.domElement);

	// create an empty scene
	scene = new THREE.Scene();

	// add perspective camera 
	camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 10);
	camera.position.set(0.0, 0.25, 1.0);
	scene.add(camera);
	
	loadAssets();
}

function loadAssets()
{
	// necessary loader objects
	var json_loader = new THREE.JSONLoader();
	var tex_loader = new THREE.TextureLoader();
	var tex_cube_loader = new THREE.CubeTextureLoader();
	
	var tex_cube = tex_cube_loader.setPath('assets/textures/cube/').load(['px.jpg', 'nx.jpg', 'py.jpg', 'ny.jpg', 'pz.jpg', 'nz.jpg']);
	tex_cube.format = THREE.RGBFormat;
	scene.background = tex_cube;
	
	var tex_plane_ao = tex_loader.load("assets/textures/plane_ao.jpg");	
	
	// materials
	var mat_normals = new THREE.MeshNormalMaterial();
	var mat_basic = new THREE.MeshBasicMaterial({color: 0xf04123});
	var mat_lambert = new THREE.MeshLambertMaterial({color: 0xf04123});
	
	var mat_plane = new THREE.MeshBasicMaterial();
	mat_plane.map = tex_plane_ao;
	
	var geometry = new THREE.SphereGeometry(0.25, 32, 32);
	var sphere = new THREE.Mesh(geometry, mat_basic);
	scene.add(sphere);	
	
	// load model files
	json_loader.load('assets/models/plane.json', function (geometry) 
	{
		var mesh_plane = new THREE.Mesh(geometry, mat_plane);
		scene.add(mesh_plane);
	});	
}

// update loop
function update() 
{
	requestAnimationFrame(update);
	
	// render the scene
	render();

	// update stats
	stats.update();
}

function render() 
{
	renderer.render(scene, camera);
}