var stats, scene, renderer;
var camera;

if(!init()) update();

// init the scene
function init()
{
	if(Detector.webgl)
	{
		renderer = new THREE.WebGLRenderer({
			antialias : true
		});
		renderer.setClearColor(0xffffff, 1);
	}
	else
	{
		Detector.addGetWebGLMessage();
		return true;
	}
	
	var w = window.innerWidth;
	var h = window.innerHeight;

	renderer.setPixelRatio(window.devicePixelRatio);
	renderer.setSize(w, h);
	document.getElementById('container').appendChild(renderer.domElement);

	stats = new Stats();
	stats.domElement.style.position	= 'absolute';
	stats.domElement.style.bottom = '0px';
	document.body.appendChild(stats.domElement);

	// create an empty scene
	scene = new THREE.Scene();

	// add perspective camera 
	camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 10);
	camera.position.set(0.0, 0.25, 1.0);
	scene.add(camera);
	
	loadAssets();
}

function loadAssets()
{
	// materials
	var mat_normals = new THREE.MeshNormalMaterial();
	var mat_basic = new THREE.MeshBasicMaterial({color: 0xf04123});
	var mat_lambert = new THREE.MeshLambertMaterial({color: 0xf04123});
	
	var geometry = new THREE.SphereGeometry(0.25, 32, 32);
	var sphere = new THREE.Mesh(geometry, mat_basic);
	scene.add( sphere );	
}

// update loop
function update() 
{
	requestAnimationFrame(update);
	
	// render the scene
	render();

	// update stats
	stats.update();
}

function render() 
{
	renderer.render(scene, camera);
}