
var stats, scene, renderer;
var camera, orbit, mouse;
var raycaster, intersects, pickables;

var mesh_button;

var tween_btn;
var dir_mult = 1;
var browning_range = 0;

if(!init()) update();

// init the scene
function init()
{
	if(Detector.webgl)
	{
		renderer = new THREE.WebGLRenderer({
			antialias : true,
			preserveDrawingBuffer : true
		});
		renderer.setClearColor(0xffffff, 1);
	}
	else
	{
		Detector.addGetWebGLMessage();
		return true;
	}
	
	var w = window.innerWidth;
	var h = window.innerHeight;

	renderer.setPixelRatio(window.devicePixelRatio);
	renderer.setSize(w, h);
	document.getElementById('container').appendChild(renderer.domElement);

	stats = new Stats();
	stats.domElement.style.position	= 'absolute';
	stats.domElement.style.bottom = '0px';
	document.body.appendChild(stats.domElement);

	// create an empty scene
	scene = new THREE.Scene();

	// add perspective camera 
	camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 10);
	camera.position.set(-0.5, 0.25, 0.5);
	scene.add(camera);

	raycaster = new THREE.Raycaster();
	mouse = new THREE.Vector2();	
	pickables = [];
	
	// add a light
	scene.add(new THREE.HemisphereLight(0xcccccc, 0x444444, 1.0));
	
	// create a camera contol
	orbit = new THREE.OrbitControls(camera, renderer.domElement)
	orbit.target.set(0.0, 0.1, 0.0);
	orbit.minDistance = 0.5;
	orbit.maxDistance = 1.0;
	orbit.enablePan = false;
	orbit.enableDamping = true;
	orbit.rotateSpeed = 0.25;
	orbit.maxPolarAngle = Math.PI * 0.5;

	registerEvents();
	loadAssets();
}

function loadAssets()
{
	// necessary loader objects
	var json_loader = new THREE.JSONLoader();
	var tex_loader = new THREE.TextureLoader();
	var tex_cube_loader = new THREE.CubeTextureLoader();
	
	var tex_cube = tex_cube_loader.setPath('assets/textures/cube/').load(['px.jpg', 'nx.jpg', 'py.jpg', 'ny.jpg', 'pz.jpg', 'nz.jpg']);
	tex_cube.format = THREE.RGBFormat;
	//scene.background = tex_cube;

	var tex_uv = tex_loader.load("assets/textures/uv_checker.jpg");
	var tex_plane_ao = tex_loader.load("assets/textures/plane_ao.jpg");
	
	var tex_steel = tex_loader.load("assets/textures/steel.jpg");
	tex_steel.wrapS = THREE.RepeatWrapping;
	tex_steel.wrapT = THREE.RepeatWrapping;
	tex_steel.repeat.set(4, 4);

	var tex_toasted = tex_loader.load("assets/textures/toasted.jpg");
	var tex_untoasted = tex_loader.load("assets/textures/untoasted.jpg");
	var tex_toastmask = tex_loader.load("assets/textures/toast_mask.jpg");
	
	// materials
	var mat_normals = new THREE.MeshNormalMaterial();
	var mat_plane = new THREE.MeshBasicMaterial();
	mat_plane.map = tex_plane_ao;
	
	var mat_plastic = new THREE.MeshStandardMaterial();
	mat_plastic.color = new THREE.Color(0xf04123);
	mat_plastic.envMap = tex_cube;
	mat_plastic.roughness = 0.9;
	mat_plastic.metalness = 0.0;
	
	var mat_chrome = new THREE.MeshStandardMaterial();
	mat_chrome.envMap = tex_cube;
	mat_chrome.roughnessMap = tex_steel;
	mat_chrome.metalness = 1.0;

	mat_toast = new THREE.ShaderMaterial({
		uniforms: {
			browning: {type: "f", value: 0.0},
			map_untoasted: {type: "t", value: tex_untoasted},
			map_toasted: {type: "t", value: tex_toasted},
			map_toastmask: {type: "t", value: tex_toastmask}
		},
		vertexShader: document.getElementById('vertexShader').textContent,
		fragmentShader: document.getElementById('fragmentShader').textContent
	});
	
	// load model files
	json_loader.load('assets/models/plane.json', function (geometry) 
	{
		var mesh_plane = new THREE.Mesh(geometry, mat_plane);
		scene.add(mesh_plane);
	});	
	
	json_loader.load('assets/models/toaster.json', function (geometry) 
	{
		var mesh_toaster = new THREE.Mesh(geometry, mat_chrome);
		scene.add(mesh_toaster);
	});	
	
	json_loader.load('assets/models/footer.json', function (geometry) 
	{
		var mesh_footer = new THREE.Mesh(geometry, mat_plastic);
		scene.add(mesh_footer);
	});	

	json_loader.load('assets/models/knob.json', function (geometry) 
	{
		var mesh_knob = new THREE.Mesh(geometry, mat_plastic);
		mesh_knob.name = "knob";
		scene.add(mesh_knob);
		pickables.push(mesh_knob);
	});	
	
	json_loader.load('assets/models/button.json', function (geometry) 
	{
		mesh_button = new THREE.Mesh(geometry, mat_plastic);
		mesh_button.name = "button";
		scene.add(mesh_button);
		pickables.push(mesh_button);
		
		json_loader.load('assets/models/toast0.json', function (geometry) 
		{
			var mesh_toast0 = new THREE.Mesh(geometry, mat_toast);
			mesh_button.add(mesh_toast0);
		});	

		json_loader.load('assets/models/toast1.json', function (geometry) 
		{
			var mesh_toast1 = new THREE.Mesh(geometry, mat_toast);
			mesh_button.add(mesh_toast1);
		});	
	});		
}

function registerEvents()
{
	window.addEventListener('resize', onWindowResize, false);
	window.addEventListener('mousemove', onMouseMove, false);
	window.addEventListener('click', onMouseClick, false);
	window.addEventListener('keydown', onKeyDown, false);
}

function onWindowResize()
{
	var w = window.innerWidth;
	var h = window.innerHeight;

	renderer.setSize(w, h);

	camera.aspect = w / h;
	camera.updateProjectionMatrix();
}

function onKeyDown(event) 
{
	// p - key
	if(event.which == 80)
	{
		var dataUrl = renderer.domElement.toDataURL("image/png");
		window.open(dataUrl, '_blank');
	}
}

function onMouseClick(event) 
{
	if (intersects.length > 0 && intersects[0].object.name == "button") 	
	{
		var btn = intersects[0].object;
		
		var tween_p0 = {y : btn.position.y};
		var tween_p1 = {y : btn.position.y - 0.075 * dir_mult};
		tween_btn = new TWEEN.Tween(tween_p0).to(tween_p1, 1500);
		tween_btn.easing(TWEEN.Easing.Elastic.Out)
		tween_btn.onUpdate(function()
		{
			btn.position.y = tween_p0.y;
		});			
		tween_btn.onComplete(function()
		{
			dir_mult *= -1;
		});			
		tween_btn.start();
	}
	
	if (intersects.length > 0 && intersects[0].object.name == "knob") 	
	{
		var b1 = browning_range;
		var b2 = (b1 + 1) % 2;

		var browning = {val : b1};
		var tween_toast = new TWEEN.Tween(browning).to({val : b2}, 4000);
		tween_toast.onUpdate(function() 
		{
			mat_toast.uniforms.browning.value = this.val;
			mat_toast.needsUpdate = true;
		});
		
		tween_toast.onComplete(function()
		{
			browning_range = b2;
		});			
		
		tween_toast.start();
	}
}

function onMouseMove(event) 
{
	mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
	mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
}

function raycastScene()
{
	// update the picking ray with the camera and mouse position
	raycaster.setFromCamera(mouse, camera);
	
	// calculate objects intersecting the picking ray
	intersects = raycaster.intersectObjects(pickables);
	
	document.body.style.cursor = 'default';
	// indicate if any pickables are hit
	if (intersects.length > 0) 
	{
		document.body.style.cursor = 'pointer';
	}
}

// update loop
function update() 
{
	requestAnimationFrame(update);
	
	// raycast into scene
	raycastScene();
	
	// update camera controls
	orbit.update();

	// update potentially triggered tweens 
	TWEEN.update();	
	
	// render the scene
	render();

	// update stats
	stats.update();
}

function render() 
{
	renderer.render(scene, camera);
}