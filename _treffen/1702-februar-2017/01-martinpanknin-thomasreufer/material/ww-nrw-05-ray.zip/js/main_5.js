var stats, scene, renderer;
var camera, orbit, mouse;

var raycaster, intersects, pickables;

var mesh_button;

if(!init()) update();

// init the scene
function init()
{
	if(Detector.webgl)
	{
		renderer = new THREE.WebGLRenderer({
			antialias : true
		});
		renderer.setClearColor(0xffffff, 1);
	}
	else
	{
		Detector.addGetWebGLMessage();
		return true;
	}
	
	var w = window.innerWidth;
	var h = window.innerHeight;

	renderer.setPixelRatio(window.devicePixelRatio);
	renderer.setSize(w, h);
	document.getElementById('container').appendChild(renderer.domElement);

	stats = new Stats();
	stats.domElement.style.position	= 'absolute';
	stats.domElement.style.bottom = '0px';
	document.body.appendChild(stats.domElement);

	// create an empty scene
	scene = new THREE.Scene();

	// add perspective camera 
	camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 10);
	camera.position.set(-0.5, 0.25, 0.5);
	scene.add(camera);
	
	raycaster = new THREE.Raycaster();
	mouse = new THREE.Vector2();	
	pickables = [];
	
	// add a light
	scene.add(new THREE.HemisphereLight(0xcccccc, 0x444444, 1.0));
	
	// create a camera contol
	orbit = new THREE.OrbitControls(camera, renderer.domElement)
	orbit.target.set(0.0, 0.1, 0.0);
	orbit.minDistance = 0.5;
	orbit.maxDistance = 1.0;
	orbit.enablePan = false;
	orbit.enableDamping = true;
	orbit.rotateSpeed = 0.25;
	orbit.maxPolarAngle = Math.PI * 0.5;
	
	registerEvents();
	
	loadAssets();
}

function loadAssets()
{
	// necessary loader objects
	var json_loader = new THREE.JSONLoader();
	var tex_loader = new THREE.TextureLoader();
	var tex_cube_loader = new THREE.CubeTextureLoader();
	
	var tex_cube = tex_cube_loader.setPath('assets/textures/cube/').load(['px.jpg', 'nx.jpg', 'py.jpg', 'ny.jpg', 'pz.jpg', 'nz.jpg']);
	tex_cube.format = THREE.RGBFormat;
	// scene.background = tex_cube;

	var tex_uv = tex_loader.load("assets/textures/uv_checker.jpg");
	var tex_plane_ao = tex_loader.load("assets/textures/plane_ao.jpg");
	
	var tex_steel = tex_loader.load("assets/textures/steel.jpg");
	tex_steel.wrapS = THREE.RepeatWrapping;
	tex_steel.wrapT = THREE.RepeatWrapping;
	tex_steel.repeat.set(4, 4);

	var tex_toasted = tex_loader.load("assets/textures/toasted.jpg");
	var tex_untoasted = tex_loader.load("assets/textures/untoasted.jpg");
	var tex_toastmask = tex_loader.load("assets/textures/toast_mask.jpg");
	
	// materials
	var mat_normals = new THREE.MeshNormalMaterial();
	
	var mat_toast = new THREE.MeshLambertMaterial();
	mat_toast.map = tex_untoasted;
	
	var mat_plane = new THREE.MeshBasicMaterial();
	mat_plane.map = tex_plane_ao;
	
	var mat_plastic = new THREE.MeshStandardMaterial();
	mat_plastic.color = new THREE.Color(0xf04123);
	mat_plastic.envMap = tex_cube;
	mat_plastic.roughness = 0.9;
	mat_plastic.metalness = 0.0;
	
	var mat_chrome = new THREE.MeshStandardMaterial();
	mat_chrome.envMap = tex_cube;
	mat_chrome.roughnessMap = tex_steel;
	mat_chrome.metalness = 1.0;

	// load model files
	json_loader.load('assets/models/plane.json', function (geometry) 
	{
		var mesh_plane = new THREE.Mesh(geometry, mat_plane);
		scene.add(mesh_plane);
	});	
	
	json_loader.load('assets/models/toaster.json', function (geometry) 
	{
		var mesh_toaster = new THREE.Mesh(geometry, mat_chrome);
		scene.add(mesh_toaster);
	});	
	
	json_loader.load('assets/models/footer.json', function (geometry) 
	{
		var mesh_footer = new THREE.Mesh(geometry, mat_plastic);
		scene.add(mesh_footer);
	});	

	json_loader.load('assets/models/knob.json', function (geometry) 
	{
		var mesh_knob = new THREE.Mesh(geometry, mat_plastic);
		scene.add(mesh_knob);
		
		mesh_knob.name = "knob";
		pickables.push(mesh_knob);
	});	
	
	json_loader.load('assets/models/button.json', function (geometry) 
	{
		mesh_button = new THREE.Mesh(geometry, mat_plastic);
		scene.add(mesh_button);
		
		mesh_button.name = "button";
		pickables.push(mesh_button);
		
		json_loader.load('assets/models/toast0.json', function (geometry) 
		{
			var mesh_toast0 = new THREE.Mesh(geometry, mat_toast);
			mesh_button.add(mesh_toast0);
		});	

		json_loader.load('assets/models/toast1.json', function (geometry) 
		{
			var mesh_toast1 = new THREE.Mesh(geometry, mat_toast);
			mesh_button.add(mesh_toast1);
		});	
	});	
}

function registerEvents()
{
	window.addEventListener('resize', onWindowResize, false);
	window.addEventListener('mousemove', onMouseMove, false);
	window.addEventListener('click', onMouseClick, false);
	window.addEventListener('keydown', onKeyDown, false);
}

function onWindowResize()
{
	var w = window.innerWidth;
	var h = window.innerHeight;

	renderer.setSize(w, h);

	camera.aspect = w / h;
	camera.updateProjectionMatrix();
}

function onKeyDown(event) 
{
}

function onMouseClick(event) 
{
	if (intersects.length > 0 && intersects[0].object.name == "button") 	
	{
		var btn = intersects[0].object;
		
		console.log(btn.name);
	}
	
	if (intersects.length > 0 && intersects[0].object.name == "knob") 	
	{
		var knob = intersects[0].object;
		
		console.log(knob.name);
	}
}

function onMouseMove(event) 
{
	mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
	mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
}

function raycastScene()
{
	// update the picking ray with the camera and mouse position
	raycaster.setFromCamera(mouse, camera);
	
	// calculate objects intersecting the picking ray
	intersects = raycaster.intersectObjects(pickables);
	
	document.body.style.cursor = 'default';
	// indicate if any pickables are hit
	if (intersects.length > 0) 
	{
		document.body.style.cursor = 'pointer';
	}
}

// update loop
function update() 
{
	requestAnimationFrame(update);
	
	// update camera controls
	orbit.update();	
	
	// raycast into scene
	raycastScene();
	
	// render the scene
	render();

	// update stats
	stats.update();
}

function render() 
{
	renderer.render(scene, camera);
}